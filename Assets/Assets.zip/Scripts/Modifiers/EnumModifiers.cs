namespace UnityEngine
{
    public enum ModifierName
    {
        ElectricAOE,
        Thunderbolt,
        Rage
    }
}
