public interface IWeaponModifier
{
    public void PrepareModifier(ModifierBaseObject modifierConfig);
    public void UpdateModifierInfo(ModifierBaseObject modifierConfig);
}
