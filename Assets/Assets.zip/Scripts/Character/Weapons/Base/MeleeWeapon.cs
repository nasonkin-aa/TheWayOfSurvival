using UnityEngine;

public class MeleeWeapon : Weapon
{
    public override void Attack(Vector3 direction, Vector3 atackPoint)
    {
        throw new System.NotImplementedException();
    }
}
