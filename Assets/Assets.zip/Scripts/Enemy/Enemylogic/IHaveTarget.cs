using UnityEngine;

public interface IHaveTarget
{
    public Transform GetTarget();
}
